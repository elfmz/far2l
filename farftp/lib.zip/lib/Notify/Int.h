#ifndef __FTP_NOTIFY_INTERNAL
#define __FTP_NOTIFY_INTERNAL

#include "fstdlib.h"         //FAR plugin stdlib
#include "../Plugin.h"

#endif